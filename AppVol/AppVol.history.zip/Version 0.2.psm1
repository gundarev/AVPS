
#requires -Version 3 

#region Internal Functions
	
#.ExternalHelp AppVol.psm1-help.xml

	
Function Select-FilteredResults 
{
    param (
        $ParamKeys, 
        $Entities
		
    )

        
    [regex] $RegexParams = '(?i)^(All|Filter|Exact|Not|Id|EntityType|MachineManagerId|Id|VolumeType|Volume|ErrorAction|WarningAction|Verbose|Debug|ErrorVariable|WarningVariable|OutVariable|OutBuffer|PipelineVariable)$'
    $FilteredParamKeys = $ParamKeys -notmatch $RegexParams
		

    if ($FilteredParamKeys.count -gt 0) 
    {
        $EntitiesFiltered = @()
        foreach ($Entity in $Entities)
        {
            foreach ($CurrentParameter in $($FilteredParamKeys))
		
            {
                $EntityList = @()
                switch ($PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter].GetType().Name)
                {
                    {
                        ($_ -match 'String') -or ($_ -eq 'IPAddress')
                    }
                    {
                        if ($Exact)
                        {
                            if ($Entity.$CurrentParameter -eq $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and (-not $Not))
                            {
                                $EntityList += $Entity
                            }
                            elseif ($Entity.$CurrentParameter -ne $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and ($Not))
                            {
                                $EntityList += $Entity
                            }
                        }
                        if ($Like -or ((-not $Exact) -and (-not $Like) -and (-not $Exact)))
                        {
                            if ($Entity.$CurrentParameter -like '*' + $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] + '*' -and (-not $Not))
                            {
                                $EntityList += $Entity
                            }
                            elseif ($Entity.$CurrentParameter -notlike '*' + $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] + '*' -and ($Not))
                            {
                                $EntityList += $Entity
                            }
                        }
                    }
                    {
                        ($_ -match 'AssignmentStatus') -or 
                        ($_ -eq 'ProvisioningStatus')-or 
                        ($_ -eq 'DatastoreCategory') -or
                        ($_ -eq 'Guid') -or 
                        ($_ -eq 'VolumeStatus') -or  
                        ($_ -eq 'ComputerType')-or  
                        ($_ -eq 'AgentStatus')
                    }
                   
                    {
                        if ($Entity.$CurrentParameter -eq $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and (-not $Not))
                        {
                            $EntityList += $Entity
                        }
                        elseif ($Entity.$CurrentParameter -ne $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and ($Not))
                        {
                            $EntityList += $Entity
                        }
                    }
                    
                    {
                        ($_ -match 'Int') -or ($_ -eq 'DateTime')
                    }
                    {
                        if ($Exact -or ((-not $Exact) -and (-not $gt) -and (-not $lt) -and (-not $ge) -and (-not $le)))
                        {
                            if ($Entity.$CurrentParameter -eq $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and (-not $Not))
                            {
                                $EntityList += $Entity
                            }
                            elseif ($Entity.$CurrentParameter -ne $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and ($Not))
                            {
                                $EntityList += $Entity
                            }
                        }
                        if ($gt)
                        {
                            if ($Entity.$CurrentParameter -gt $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and (-not $Not))
                            {
                                $EntityList += $Entity
                            }
                            elseif ($Entity.$CurrentParameter -le $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and ($Not))
                            {
                                $EntityList += $Entity
                            }
                        }
                        if ($lt)
                        {
                            if ($Entity.$CurrentParameter -lt $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and (-not $Not))
                            {
                                $EntityList += $Entity
                            }
                            elseif ($Entity.$CurrentParameter -ge $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and ($Not))
                            {
                                $EntityList += $Entity
                            }
                        }
                        if ($ge)
                        {
                            if ($Entity.$CurrentParameter -ge $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and (-not $Not))
                            {
                                $EntityList += $Entity
                            }
                            elseif ($Entity.$CurrentParameter -lt $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and ($Not))
                            {
                                $EntityList += $Entity
                            }
                        }
                        if ($le)
                        {
                            if ($Entity.$CurrentParameter -le $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and (-not $Not))
                            {
                                $EntityList += $Entity
                            }
                            elseif ($Entity.$CurrentParameter -gt $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and ($Not))
                            {
                                $EntityList += $Entity
                            }
                        }
                    }
                   
                    {
                        (($_ -eq 'SwitchParameter') -and (-not (@('gt', 'ge', 'lt', 'le', 'Exact', 'Like', 'Not') -contains $CurrentParameter )))
                    }
                    {
                        if ($Entity.$CurrentParameter -eq $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and (-not $Not))
                        {
                            $EntityList += $Entity
                        }
                        elseif ($Entity.$CurrentParameter -ne $PSCmdlet.MyInvocation.BoundParameters[$CurrentParameter] -and ($Not))
                        {
                            $EntityList += $Entity
                        }
                    }
                }
            }
            if ($EntityList.Count -ge 1)
            {
                $EntitiesFiltered += $EntityList
            }
        }
        return $EntitiesFiltered
    }
    else 
    {
        return $Entities
    }
}
	
Function Invoke-InternalRest
{
    param(
        [Parameter(Position = 1,Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [VMware.AppVolumes.Session]$Session,
		
        [Parameter(Position = 2,Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({
                    ([System.URI]$_).IsAbsoluteUri
        })]
        [string]$Uri,
		
        [Parameter(Position = 3,Mandatory = $false)]
        [ValidateNotNullOrEmpty()]
        [Microsoft.PowerShell.Commands.WebRequestMethod]$Method = [Microsoft.PowerShell.Commands.WebRequestMethod]::Get,
		
        [Parameter(Position = 4,Mandatory = $false)]
        [ValidateNotNullOrEmpty()]
        [string]$Body
		
    )
    switch ([Microsoft.PowerShell.Commands.WebRequestMethod]$Method)
    {
			
        Put
        {
            $cmd = {
                Invoke-RestMethod -Uri $Uri -Method $Method -WebSession $Session.WebRequestSession -Headers $Session.Headers -Body $Body -ContentType 'application/json'
            }
        }
        Post
        {
            $cmd = {
                $res = Invoke-WebRequest -Uri $Uri -TimeoutSec $([int]::MaxValue) -Method $Method -WebSession $Session.WebRequestSession -Headers $Session.Headers -Body $Body -ContentType 'application/json'
                try 
                {
                    return $res|ConvertFrom-Json
                }
                catch 
                {
                    return $res
                }
            }
        }
			
        default
        {
            $cmd = {
                Invoke-RestMethod -Uri $Uri -Method $Method -WebSession $Session.WebRequestSession -Headers $Session.Headers -ContentType 'application/json'
            }
        }
    }
    try
    {
        $WebRequestResult = Invoke-Command $cmd
        $message = @{
            WebRequestResult = $WebRequestResult
            Success          = $true
        }
        return $message
    }
    catch
    {
        $WebRequestResult = $_.Exception.Response.GetResponseStream()
        $reader = New-Object -TypeName System.IO.StreamReader -ArgumentList ($WebRequestResult)
        $reader.BaseStream.Position = 0
        #$reader.DiscardBufferedData()
        $responseBody = [System.Web.HttpUtility]::HtmlDecode($reader.ReadToEnd())
        $message = @{
            error   = $_.Exception.Response.StatusCode.value__
            message = $responseBody
            Success = $false
        }
        return $message
    }
}
	
Function Invoke-InternalGetRest
{
    param(
        [Parameter(Position = 1,Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({
                    ([System.URI]$_).IsAbsoluteUri
        })]
        [string]$Uri,
        
        [Parameter(Position = 2,Mandatory = $false)]
        [ValidateNotNullOrEmpty()]
		
        [string]$Object
    )
    $RestResult = Invoke-InternalRest -Uri $Uri -Method Get -Session $Global:GlobalSession
    if ($RestResult.Success)
    {
        $Result = if ($Object) 
        {
            $ObjectArray = $Object.Split('.')
            $cmd = "`$RestResult.WebRequestResult"
            foreach ($SubObject in $ObjectArray)
            {
                $cmd = $cmd +'.'+ $SubObject
            }
            $cmdscript = [scriptblock]::Create($cmd)
            Invoke-Command $cmdscript
        } 
        else 
        {
            $RestResult.WebRequestResult
        }
        return $Result
    }
    else
    {
        Write-Warning -Message $RestResult.message
    }
}
	
Function Invoke-InternalPostRest
{
    param(
        [Parameter(Position = 1,Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({
                    ([System.URI]$_).IsAbsoluteUri
        })]
        [string]$Uri,
        
        [Parameter(Position = 2,Mandatory = $false)]
        [ValidateNotNullOrEmpty()]
		
        [string]$Object,

        [Parameter(Position = 3,Mandatory = $false)]
		
		
        [string]$Body
    )
    if ($Body) 
    {
        $RestResult = Invoke-InternalRest -Uri $Uri -Method Post   -Session $Global:GlobalSession -Body $Body
    }
    else 
    {
        $RestResult = Invoke-InternalRest -Uri $Uri -Method Post -Session $Global:GlobalSession
    }
    if ($RestResult.Success)
    {
        $Result = if ($Object) 
        {
            $ObjectArray = $Object.Split('.')
            $cmd = "`$RestResult.WebRequestResult"
            foreach ($SubObject in $ObjectArray)
            {
                $cmd = $cmd +'.'+ $SubObject
            }
            $cmdscript = [scriptblock]::Create($cmd)
            Invoke-Command $cmdscript
        } 
        else 
        {
            $RestResult.WebRequestResult
        }
        return $Result
    }
    else
    {
        Write-Warning -Message $RestResult.message
    }
}



	
	
	
Function Initialize-Assignment
{
    param(
        $instance
    )
		
    $splitChar = '\'
    $Assignment = New-Object -TypeName Vmware.Appvolumes.Assignment
    $Assignment.DistignushedName = $instance.entity_dn
    $Assignment.EntityType = $instance.entityt
    if ($Assignment.EntityType -eq 'OrgUnit') 
    {
        $splitChar = ' '
    }
    $Assignment.SamAccountName = $instance.entity_upn.Split($splitChar)[1]
    $Assignment.Domain = $instance.entity_upn.Split($splitChar)[0]
    $Assignment.EntityType = $instance.entityt
    $Assignment.EventTime = $instance.event_time
    $Assignment.MountPrefix = $instance.mount_prefix

    return $Assignment
}
	
	
	
#endregion


. $psScriptRoot\Modules\DataStore.ps1
. $psScriptRoot\Modules\DataStoreConfig.ps1
. $psScriptRoot\Modules\Entity.ps1
. $psScriptRoot\Modules\Files.ps1
. $psScriptRoot\Modules\MachineManager.ps1
. $psScriptRoot\Modules\MetaData.ps1
. $psScriptRoot\Modules\Provisioning.ps1
. $psScriptRoot\Modules\VolumeMaintenance.ps1
. $psScriptRoot\Modules\Session.ps1
. $psScriptRoot\Modules\Template.ps1
. $psScriptRoot\Modules\Version.ps1
. $psScriptRoot\Modules\Volume.ps1
. $psScriptRoot\Modules\VolumeFile.ps1






Function TODOGetAppVolAppStackProvisioning
{
    [CmdletBinding(DefaultParameterSetName = 'AppStackAndComputer')]
    param(
        [Parameter(ParameterSetName = 'AppStackAndComputer',Mandatory = $false,Position = 0)]
        [Parameter(ParameterSetName = 'AppStackAndComputerId',Mandatory = $false,Position = 0)]
        [ValidateNotNull()]
        [VMware.AppVolumes.AppVolumesAppStack]$AppStack,
	
        [Parameter(ParameterSetName = 'AppStackAndComputer',Mandatory = $false,Position = 1)]
        [Parameter(ParameterSetName = 'AppStackIdAndComputer',Mandatory = $false,Position = 1)]
        [ValidateScript({
                    $_.EntityType -eq 'Computer'
        })]
        [VMware.AppVolumes.Entity]$Computer,
	
        [Parameter(ParameterSetName = 'AppStackIdAndComputer',Mandatory = $false,Position = 1)]
        [Parameter(ParameterSetName = 'AppStackIdAndComputerId',Mandatory = $false,Position = 1)]
	
        [int]$VolumeId,
        [ValidateNotNull()]
        [Parameter(ParameterSetName = 'AppStackAndComputerId',Mandatory = $false,Position = 2)]
        [Parameter(ParameterSetName = 'AppStackIdAndComputerId',Mandatory = $false,Position = 2)]
        [ValidateNotNull()]
        [int]$ComputerId
    )
	
	
    Test-AppVolSession
	
    switch ($PSCmdlet.ParameterSetName)
    {
        'AppStackAndComputer'
        {

        }
        'AppStackAndComputerId'
        {
            $Computer = Get-AppVolComputer -Id $ComputerId
        }
        'AppStackIdAndComputer'
        {
            $AppStack = Get-AppVolVolume -Id $VolumeId
        }
        'AppStackIdAndComputerId'
        {
            $Computer = Get-AppVolComputer -Id $ComputerId
            $AppStack = Get-AppVolVolume -Id $VolumeId
        }  
    }
    
    $InuseProvisioners = Get-AppVolProvisioner | Where-Object -FilterScript {
        $_.ProvisioningStatus -eq 'InUse'
    } 


    $machineguid = $(Get-AppVolProvisioner|Where-Object -FilterScript {
            $_.Id -eq $Computer.Id
    }).uuid
    $ApiUri = "$($Global:GlobalSession.Uri)cv_api/provisions/$($AppStack.Id)/start"
    $postParams = @{
        computer_id = $Computer.Id
        uuid        = $machineguid
    }|ConvertTo-Json
    try
    {
        $response = Invoke-InternalRest -Session $Global:GlobalSession -Uri $ApiUri -Method Post -Body $postParams
        if ($response.Success)
        {
            $WebRequestResult = $response.WebRequestResult|ConvertFrom-Json
            return $WebRequestResult
        }
        else 
        {
            throw $response.message
        }
    }
    catch
    {
        Write-Error -Message $_.Exception.message
    }	
}

#.ExternalHelp AppVol.psm1-help.xml
Function TODOGetAppVolAssignment
{
    [CmdletBinding(DefaultParameterSetName = 'None')]
    param(

        [Parameter(ParameterSetName = 'SelectedVolumeId',Mandatory = $false,Position = 0,ValueFromPipeline = $true)]
        [Alias('id')]
        [ValidateNotNull()]
        [int[]]$Id,
	
        [Parameter(ParameterSetName = 'SelectedVolume',Mandatory = $false,Position = 0,ValueFromPipeline = $true)]
        [ValidateNotNull()]
        [VMware.AppVolumes.Volume[]]$Volume,
	
	
        [ValidateNotNull()]
        [string]$DistignushedName,
	
        [ValidateNotNull()]
        [string]$SamAccountName,
	
        [ValidateNotNull()]
        [string]$Domain,
	
        [ValidateNotNull()]
        [Vmware.Appvolumes.EntityType]$EntityType,
	
        [ValidateNotNull()]
        [datetime]$EventTime,
	
        [ValidateNotNull()]
        [string]$MountPrefix,
	
	
        [ValidateNotNull()]
        [string]$VolumeName,
	
        [switch]$Exact,
        [switch]$Like,
	
        [switch]$ge,
        [switch]$le,
        [switch]$gt,
        [switch]$lt,
	
        [switch]$Not
	
    )
    begin
    {
        Test-AppVolSession
        $ApiUri = "$($Global:GlobalSession.Uri)cv_api/assignments"
        [Vmware.Appvolumes.Assignment []]$Entities = $null
        $AllAppStacks

    }
    process
    {
        if (($PSCmdlet.ParameterSetName -eq 'None') -and (!$Id) -and (!$Volume))
        {
            $AllAssignments = Invoke-InternalGetRest -Uri $ApiUri -Object 'assignments'
            foreach ($AssignmentInstance in $AllAssignments)
            {
                $Entities += Initialize-Assignment $Entity
            }
        }
        if  (($Id) -or ($Volume))
        {           
            $LocalVolumeId = if ($Id) 
            {
                $Id
            }
            else 
            {
                $Volume.Id
            }
            $AllAssignments = Invoke-InternalGetRest -Uri $ApiUri -Object 'assignments'
            foreach ($AssignmentInstance in $AllAssignments)
            {
                $LocalAssignment = Initialize-Assignment $Entity
                if ($LocalAssignment.Id -eq $Id)
                {
                    $Entities += $LocalAssignment
                }
            }
        }
    }
    end
    {
        return Select-FilteredResults $PSCmdlet.MyInvocation.BoundParameters.Keys $Entities
    }
}





Function StartAppVolVolumeMaintenance
{
    param(
        [Parameter(Mandatory = $true,Position = 0,ValueFromPipeline = $false)]
        [ValidateNotNullOrEmpty()]
        [string]$ComputerName,
	
        [Parameter(Mandatory = $true,Position = 1,ValueFromPipeline = $true)]
        [ValidateNotNullOrEmpty()]
        [VMware.AppVolumes.Volume]$Volume
	
    )
    $parentVolume = Get-AppVolVolume -Id $Volume.Parent -VolumeType:AppStack
    if ($parentVolume.PrimordialOs)
    {
        $osver = $AppVolOSDictionary.$($parentVolume.PrimordialOs.Name)
    }
    if ($parentVolume.AgentVersion)
    {
        $agentver = $parentVolume.AgentVersion
    }
    if ($parentVolume.CaptureVersion)
    {
        $agentver = $parentVolume.CaptureVersion
    }


    [ScriptBlock]$ScriptBlock = {
        param($osver,$agentver)
        Register-WmiEvent -Class win32_VolumeChangeEvent -SourceIdentifier volumeChange
        $message = $null


        $newEvent = Wait-Event -SourceIdentifier volumeChange
        $eventType = $newEvent.SourceEventArgs.NewEvent.EventType
 
        if ($eventType -eq 2)
        {
            $driveLetter = $newEvent.SourceEventArgs.NewEvent.DriveName
            $driveLabel = ([wmi]"Win32_LogicalDisk='$driveLetter'").VolumeName
            $partitionobject = Get-WmiObject -Query "Associators of {Win32_LogicalDisk.DeviceID=""$driveLetter""} WHERE AssocClass = Win32_LogicalDiskToPartition"
            $diskIndex = $partitionobject.DiskIndex
            $partitionIndex = $partitionobject.Index
            $rootDirectoryObject = Get-WmiObject -Query "Associators of {Win32_LogicalDisk.DeviceID=""$driveLetter""} WHERE AssocClass = Win32_LogicalDiskRootDirectory"
            $rootDirectory = $rootDirectoryObject.Name
            $rootDirectoryEscaped = $rootDirectory -replace '\\', '\\'
            $shareobject = Get-WmiObject -Query "select * from win32_share where Path='$rootDirectoryEscaped'"
            $share = "\\$($shareobject.PSComputerName)\$($shareobject.name)"
            $templateversion = $(Get-Content -Path "$($rootDirectory)version.txt").Split('=')[1]
            $properties = @{
                'driveLetter'   = $driveLetter
                'driveLabel'    = $driveLabel
                'diskIndex'     = $diskIndex
                'partitionIndex' = $partitionIndex
                'rootDirectory' = $rootDirectory
                'share'         = $share
                'templateversion' = $templateversion
                'osver'         = $osver
                'agentver'      = $agentver
            }
            $Object = New-Object -TypeName PSObject -Property $properties
        }
        Remove-Event -SourceIdentifier volumeChange
    
   
        Unregister-Event -SourceIdentifier volumeChange
        return $Object
    }
    $Computer = $(Get-AppVolProvisioner -Filter $ComputerName) |
    Where-Object -FilterScript {
        $_.SamAccountname -eq "$($ComputerName)$"
    }|
    Select-Object -First 1
    $volumejob = Invoke-Command -ComputerName $ComputerName  -ScriptBlock $ScriptBlock -ArgumentList $osver, $agentver -AsJob

    $null = Start-AppVolProvisioning -AppStack $Volume -Computer $Computer
    $Result = Receive-Job -Job $volumejob -Wait
    #$result.version=
    return $Result
}


function Select-FileDialog

{
    param([string]$Title,[string]$Directory,[string]$Filter = 'All Files (*.*)|*.*', [bool]$MultiSelect = $true)

    $null = [System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')

    $objForm = New-Object -TypeName System.Windows.Forms.OpenFileDialog

    $objForm.ShowHelp = $true

    $objForm.InitialDirectory = $Directory

    $objForm.Filter = $Filter

    $objForm.Title = $Title
    $objForm.Multiselect = $MultiSelect
    $objForm
    Add-Type -TypeDefinition @"
using System;
using System.Windows.Forms;
 
public class Win32Window : IWin32Window
{
   private IntPtr _hWnd;
   
   public Win32Window(IntPtr handle)
   {
       _hWnd = handle;
   }
 
   public IntPtr Handle
   {
       get { return _hWnd; }
   }
}
"@ -ReferencedAssemblies 'System.Windows.Forms.dll'

    $owner = New-Object -TypeName Win32Window -ArgumentList ([System.Diagnostics.Process]::GetCurrentProcess().MainWindowHandle)

    $Show = $objForm.ShowDialog($owner)

    If ($Show -eq 'OK')

    {
        Return $objForm.FileNames
    }

    Else

    {
        Write-Error -Message 'Operation cancelled by user.'
    }
}
function Select-FolderDialog

{
    param([string]$Title,[string]$Directory,[string]$Filter = 'All Files (*.*)|*.*', [bool]$MultiSelect = $true)

    $null = [System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')

    $objForm = New-Object -TypeName System.Windows.Forms.FolderBrowserDialog
    $objForm.Description = $Title
    $objForm.SelectedPath = $Directory
    $objForm.ShowNewFolderButton = $true

    Add-Type -TypeDefinition @"
using System;
using System.Windows.Forms;
 
public class Win32Window : IWin32Window
{
   private IntPtr _hWnd;
   
   public Win32Window(IntPtr handle)
   {
       _hWnd = handle;
   }
 
   public IntPtr Handle
   {
       get { return _hWnd; }
   }
}
"@ -ReferencedAssemblies 'System.Windows.Forms.dll'

    $owner = New-Object -TypeName Win32Window -ArgumentList ([System.Diagnostics.Process]::GetCurrentProcess().MainWindowHandle)

    $Show = $objForm.ShowDialog($owner)

    If ($Show -eq 'OK')

    {
        Return $objForm.SelectedPath
    }

    Else

    {
        Write-Error -Message 'Operation cancelled by user.'
    }
}






<# 
        .Synopsis
        Modifies AppVolumes Manager AppStack(s).
	
        .Description
        Modifies AppVolumes Manager AppStack(s).
	
        .Parameter Session
        App Volumes Manager Session.
	
        .Parameter VolumeId
        AppStack ID
        .Example
        $session=Open-AppVolSession http://appvol01.corp.itbubble.ru fdwl P@ssw0rd
	
	
#>
Function Set-TODOAppStack
{
    [CmdletBinding(DefaultParameterSetName = 'OneAppStack')]
    param(
        [Parameter(ParameterSetName = 'OneAppStack',Position = 0,Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [pscustomobject]$Session,
	
        [Parameter(ParameterSetName = 'OneAppStack',Position = 1,ValueFromPipeline = $true,ValueFromPipelineByPropertyName)]
        [Alias('id')]
        [ValidateNotNullOrEmpty()]
        [int[]]$VolumeId,
        [Parameter(ParameterSetName = 'OneAppStack',Position = 2,ValueFromPipeline = $true,ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [string]$Property,
        [Parameter(ParameterSetName = 'OneAppStack',Position = 2,ValueFromPipeline = $true,ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [string]$Value
    )
    process
    {
		
        $Uri = "$($Session.Uri)/cv_api/appstacks/$VolumeId"
		
        $Uri = "$Uri/$VolumeId"
        $WebRequestResult = $(Invoke-InternalRest -Session $Session -Uri $Uri -Method Put).appstack
		
        return $WebRequestResult | Format-Table
		
		
    }
}

<# 
        .Synopsis
        Assigns AppVolumes Manager AppStack(s).
	
        .Description
        Assigns AppVolumes Manager AppStack(s).
	
        .Parameter Session
        App Volumes Manager Session.
	
        .Parameter AppStack
        AppStack ID
        .Parameter ADObject
        SamAccountName
        .Example
        # Login to the App Volumes manager.
        $session=New-AppVolSession -Uri "http://appvol.domain.com" -Username "admin" -Password "P@ssw0rd"
        Add-AppVolAppStackAssignment -Session $session -AppStack 1
	
	
#>
Function TODOAddAppStackAssignment
{
    param(
	
        [pscustomobject]$Session,
	
        [int]$AppStack,
        [string]$ADObject
    )
    $Uri = "$($Session.Uri)/cv_api/assignments"
	
    $headers = New-Object -TypeName 'System.Collections.Generic.Dictionary[[String],[String]]'
    $headers.Add('X-CSRF-Token',$Session.Token)
    $Search = New-Object -TypeName DirectoryServices.DirectorySearcher -ArgumentList ([adsi]'')
    $Search.filter = "(&(sAMAccountName=$ADObject))"
    $ADWebRequestResults = $Search.Findall()
    $assignments = @{
        entity_type = ($ADWebRequestResults[0].Properties['objectclass'])[($ADWebRequestResults[0].Properties['objectclass']).Count - 1]
        path        = $($ADWebRequestResults[0].Properties['DistinguishedName'])
    }
	
    $json = @{
        'action_type' = 'Assign'
        'id'         = $AppStack
        'assignments' = @{
            '0' = $assignments
        }
        'rtime'      = 'false'
        'mount_prefix' = $null
    }
	
    $Body = $json | ConvertTo-Json -Depth 3
	
    $WebRequestResult = Invoke-RestMethod -Uri $Uri -Method post -WebSession $Session.Session -Headers $headers -Body $Body -ContentType 'application/json'
    [hashtable]$Return = @{
		
    }
	
    $Return.WebRequestResult = ($WebRequestResult | Get-Member -MemberType NoteProperty)[-1].Name
    $Return.message = $WebRequestResult.(($WebRequestResult | Get-Member -MemberType NoteProperty)[-1].Name)
	
    return $Return
}


if ($PSVersionTable.PSVersion.Major -lt 3)
{
    throw New-Object -TypeName System.NotSupportedException -ArgumentList 'PowerShell V3 or higher required.'
}


Export-ModuleMember -Function *AppVol*
$Global:AppVolOSDictionary = @{
    'Windows 8.1 (x86)'          = @{
        Major = 6
        Minor = 3
        Arch  = 0
        Type  = 1
    }
    'Windows 8.1 (x64)'          = @{
        Major = 6
        Minor = 3
        Arch  = 9
        Type  = 1
    }
    'Windows 8 (x86)'            = @{
        Major = 6
        Minor = 2
        Arch  = 0
        Type  = 1
    }
    'Windows 8 (x64)'            = @{
        Major = 6
        Minor = 2
        Arch  = 9
        Type  = 1
    }
    'Windows 7 (x86)'            = @{
        Major = 6
        Minor = 1
        Arch  = 0
        Type  = 1
    }
    'Windows 7 (x64)'            = @{
        Major = 6
        Minor = 1
        Arch  = 9
        Type  = 1
    }
    'Windows Server 2012 R2 (x64)' = @{
        Major = 6
        Minor = 3
        Arch  = 9
        Type  = 3
    }
    'Windows Server 2012 (x64)'  = @{
        Major = 6
        Minor = 2
        Arch  = 9
        Type  = 3
    }
    'Windows Server 2008 R2 (x64)' = @{
        Major = 6
        Minor = 1
        Arch  = 9
        Type  = 3
    }
    'Windows Server 2008 (x86)'  = @{
        Major = 6
        Minor = 0
        Arch  = 0
        Type  = 3
    }
    'Windows Server 2008 (x64)'  = @{
        Major = 6
        Minor = 0
        Arch  = 9
        Type  = 3
    }
}


   
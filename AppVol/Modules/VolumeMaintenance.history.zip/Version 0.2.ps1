Function Start-AppVolVolumeMaintenance
{
    [outputtype([VMware.AppVolumes.VolumeMaintenance])]
    [CmdletBinding(DefaultParameterSetName = 'AppStackAndComputer')]
    param(
        [Parameter(ParameterSetName = 'AppStackAndComputer',Mandatory = $true,Position = 0,ValueFromPipeline = $TRUE)]
        [Parameter(ParameterSetName = 'AppStackAndComputerName',Mandatory = $true,Position = 0,ValueFromPipeline = $TRUE)]
        [ValidateNotNull()]
        [VMware.AppVolumes.Volume]$Volume,
	
        [Parameter(ParameterSetName = 'AppStackAndComputer',Mandatory = $true,Position = 1)]
        [Parameter(ParameterSetName = 'AppStackIdAndComputer',Mandatory = $true,Position = 1)]
        [ValidateScript({
                    $_.EntityType -eq 'Computer'
        })]
        [VMware.AppVolumes.Entity]$Computer,
	
        [Parameter(ParameterSetName = 'AppStackIdAndComputer',Mandatory = $true,Position = 1)]
        [Parameter(ParameterSetName = 'AppStackIdAndComputerName',Mandatory = $true,Position = 1)]
	
        [int]$VolumeId,
        [ValidateNotNull()]

        [Parameter(ParameterSetName = 'AppStackAndComputerName',Mandatory = $true,Position = 2)]
        [Parameter(ParameterSetName = 'AppStackIdAndComputerName',Mandatory = $true,Position = 2)]
        [ValidateNotNull()]
        [string]$ComputerName
    )

    switch ($PsCmdlet.ParameterSetName)
    {
        'AppStackAndComputer'
        {
            $ComputerName = $Computer.SamAccountName.TrimEnd('$')
        }
        'AppStackAndComputerName'
        {
            $Computer = Get-AppVolEntity -SamAccountName "$($ComputerName)$" -Exact -EntityType:Computer
        }
        'AppStackIdAndComputer'
        {
            $Volume = Get-AppVolVolume -Id $VolumeId -VolumeType:AppStack
        }
        'AppStackIdAndComputerName'
        {
            $Computer = Get-AppVolEntity -SamAccountName "$($ComputerName)$" -Exact -EntityType:Computer
            $Volume = Get-AppVolVolume -Id $VolumeId -VolumeType:AppStack
        }  
    }
    
    [ScriptBlock]$ScriptBlock= {
        $Shares = Get-WmiObject Win32_Share | Where-Object {
            $_.Name -eq 'appvolumestemp'
        }|ForEach-Object {
            $_.Delete()
        }

    
       
        Register-WmiEvent -query "Select * From __InstanceCreationEvent within 3 Where TargetInstance ISA 'Win32_Volume'" -SourceIdentifier event 
        $result=Wait-Event -SourceIdentifier event
        $Method='Create'
        $sd = ([WMIClass] 'Win32_SecurityDescriptor').CreateInstance()
        $ACE = ([WMIClass] 'Win32_ACE').CreateInstance()
        $Trustee = ([WMIClass] 'Win32_Trustee').CreateInstance()
        $Trustee.Name = 'Everyone'
        $Trustee.Domain = 'NT Authority'
        $ace.AccessMask = 2032127
        $ace.AceFlags = 3
        $ace.AceType = 0
        $ACE.Trustee = $Trustee 
        $sd.DACL += $ACE.psObject.baseobject   
        $mc = [WmiClass]'Win32_Share'
        $InParams = $mc.psbase.GetMethodParameters($Method)
        $InParams.Access = $sd
        $InParams.Description = 'App Volumes Temporary share'
        $InParams.MaximumAllowed = $Null
        $InParams.Name = 'appvolumestemp'
        $InParams.Password = $Null
        $InParams.Path = $result.SourceEventArgs.NewEvent.TargetInstance.DeviceID.Replace('?','.')
        $InParams.Type = [uint32]0

        $R = $mc.PSBase.InvokeMethod($Method, $InParams, $Null)
        return $R
    }
    
    
    $RemoteJob=Invoke-Command  -ScriptBlock $ScriptBlock  -AsJob -ComputerName $ComputerName

    Start-AppVolProvisioning -Volume $Volume -Computer $Computer|Out-Null
    if (Receive-Job -Job $RemoteJob -Wait) 
    {
        $Result = New-Object  VMware.AppVolumes.VolumeMaintenance
        $Result.Entity=$Computer
    
        
       

        $Result.Share = Get-Item "\\$($ComputerName)\appvolumestemp" 
        $Result.TemplateVersion = $(Get-Content "$($Result.Share.FullName)\version.txt" -ErrorAction:SilentlyContinue).Split('=')[1] 
        $Result.Metadata=Get-AppVolMetadata -Root  $Result.Share
        $Result.Volume = $Volume
        $Result.AgentVersion=$Computer.AgentVersion
        if ($Volume.Parent) 
        {
            $parentVolume=Get-AppVolVolume -Id $Volume.Parent -VolumeType:AppStack
            if ($parentVolume.PrimordialOs) 
            {
                $Result.PrimordialOs=$parentVolume.PrimordialOs
            }
            if ($parentVolume.CaptureVersion) 
            {
                $Result.CaptureVersion=$parentVolume.CaptureVersion
            }
        }

        return $Result
    }
}

Function Stop-AppVolVolumeMaintenance
{
    [outputtype([bool])]
    param(
        [Parameter(Mandatory = $true,Position = 0,ValueFromPipeline = $true)]
        [ValidateNotNullOrEmpty()]
        [VMware.AppVolumes.VolumeMaintenance]$VolumeMaintenance
	
        
	
    )
    $ComputerName = $VolumeMaintenance.Entity.SamAccountName.TrimEnd('$')
    
    $Result = Get-WmiObject Win32_Share -ComputerName $ComputerName | Where-Object {
        $_.Name -eq 'appvolumestemp'
    }|ForEach-Object {
        $_.Delete()
    }

      
    
    if ($Result) 
    {
        Stop-AppVolProvisioning -Volume $VolumeMaintenance.Volume 
        Remove-Item $VolumeMaintenance.Metadata.Directory -Force -Recurse
        return $true
    } 
    else 
    {
        return $false
    }
}

Function Complete-AppVolVolumeMaintenance
{
    [outputtype([VMware.AppVolumes.Volume])]
    param(
        [Parameter(Mandatory = $true,Position = 0,ValueFromPipeline = $true)]
        [ValidateNotNullOrEmpty()]
        [VMware.AppVolumes.VolumeMaintenance]$VolumeMaintenance
	
        
	
    )
    $ComputerName = $VolumeMaintenance.Entity.SamAccountName.TrimEnd('$')
    
    $osv=Get-WmiObject Win32_OperatingSystem -ComputerName $ComputerName
    $cpu=Get-WmiObject Win32_processor -ComputerName $ComputerName
    $deviceId=$(Get-WmiObject Win32_Share -ComputerName $ComputerName| Where-Object {
            $_.Name -eq 'appvolumestemp'
    }).Path.replace('.','?')
    $remotevolume = Get-WmiObject -ComputerName pvs009 win32_volume | Where-Object {
        $_.Deviceid -eq $deviceId
    }
    
    $name='svservice'
    $uuid=$VolumeMaintenance.Entity.uuid.ToString()
    $status=0
    $osver=$osv.Version
    $sp="$($osv.ServicePackMajorVersion).$($osv.ServicePackMinorVersion)"
    $suite=$osv.OSProductSuite
    $product=$osv.ProductType
    $arch=$cpu.Architecture
    $proc=$cpu.NumberOfLogicalProcessors
    $agentver=$VolumeMaintenance.AgentVersion
    #$domain='AVMAINTENANCE'
    $domain=$VolumeMaintenance.Entity.Domain
    $workstation=$ComputerName
    $volver=$VolumeMaintenance.CaptureVersion
    # $volguid=[System.Guid]::NewGuid().ToString()
    $volguid=[System.Web.HttpUtility]::UrlEncode("{$([Guid]::NewGuid())}")
    $freebytes=$remotevolume.FreeSpace
    $totalbytes=$remotevolume.Capacity

    $idstring="name=$name&uuid=$uuid&status=$status&$osver=osver&sp=$sp&suite=$suite&product=$product&arch=$arch&proc=$proc&agentver=$agentver&domain=$domain&workstation=$workstation&volver=$volver&volguid=$volguid&freebytes=$freebytes&totalbytes=$totalbytes"
    #$idstring="status=$status&$osver=osver&sp=$sp&suite=$suite&product=$product&arch=$arch&proc=$proc&agentver=$agentver&volver=$volver&volguid=$volguid&freebytes=$freebytes&totalbytes=$totalbytes"
    

 
   
    
    $UpdateUri = "$($Global:GlobalSession.Uri)update-volume-files?$idstring"
    $ProvisionUri = "$($Global:GlobalSession.Uri)provisioning-complete?$idstring&meta_file=META.ZIP"
   
    $fileBin = [IO.File]::ReadAllBytes($VolumeMaintenance.Metadata)
   
    $boundary = '==CF8F81018C504EBEAC6FB2B3CF53660A=='
    $LF = "`r`n"
    $bodyLinesstart = "--$boundary$($LF)Content-Disposition: form-data; name=`"meta`"; filename=`"META.ZIP`"$($LF)Content-Type: application/x-zip-compressed$LF$LF"
        
    $bodyLinesend = "$LF--$boundary--$LF"
    
    $body = [text.encoding]::UTF8.getbytes($bodyLinesstart)+$fileBin+[text.encoding]::ASCII.getbytes($bodyLinesend)
    $credentials = $(New-Object -typename System.Management.Automation.PSCredential ("$($VolumeMaintenance.Entity.Domain)\$($VolumeMaintenance.Entity.SamAccountName)",$(ConvertTo-SecureString 'NONE' -AsPlainText -Force)))
    
    [ScriptBlock]$ScriptBlock={
        param($UpdateUri,$ProvisionUri,$boundary, $bodyLinesstart,$bodyLinesend, $fileBin,$credentials)
        
       
        
        [System.Net.HttpWebRequest]$Provisionrequest = [System.Net.HttpWebRequest]::CreateHttp($ProvisionUri)
        $Provisionrequest.ContentType="multipart/form-data; boundary=$boundary"
        $Provisionrequest.Method='POST'
        #$Provisionrequest.Credentials= $(new-object -typename System.Management.Automation.PSCredential ('AVMAINTENANCE\AVMAINTENANCE',$(ConvertTo-SecureString 'NONE' -AsPlainText -Force)))
        $Provisionrequest.Credentials= $credentials
        $Provisionrequest.ServicePoint.Expect100Continue=$false
        $Provisionrequest.UserAgent='svservice'
        #$Provisionrequest.UseDefaultCredentials=$true
        
        

    
        [System.Net.HttpWebRequest]$Updaterequest = [System.Net.HttpWebRequest]::Create($UpdateUri)
        
        $Updaterequest.Method='GET'
        $Updaterequest.Credentials=$credentials
       
        $bufferstart = [text.encoding]::UTF8.getbytes($bodyLinesstart)
        $bufferend = [text.encoding]::ASCII.getbytes($bodyLinesend)
        $reqst = $Provisionrequest.getRequestStream()
        $reqst.write($bufferstart, 0, $bufferstart.length)
        $reqst.write($fileBin, 0, $fileBin.length)
        $reqst.write($bufferend, 0, $bufferend.length)
        $reqst.flush()
        $reqst.close()
       
        
            
        try
        {
            $Updaterequest.GetResponse()
            [net.httpWebResponse] $res = $Provisionrequest.getResponse()
        }
        catch 
        {
            $res = $_.Exception.InnerException.Response
        }
        finally
        {
            $resst = $res.getResponseStream()
            $sr = New-Object IO.StreamReader($resst)
            $result = $sr.ReadToEnd()
            $res.close()
        }
        return $result
    }
    return Invoke-Command -ComputerName $ComputerName  -ScriptBlock $ScriptBlock -ArgumentList $UpdateUri,$ProvisionUri,$boundary, $bodyLinesstart,$bodyLinesend, $fileBin,$credentials
}

#requires -Version 2 -Modules AppVol
Function Get-AppVolDataStoreConfig
{
    [OutputType([Vmware.Appvolumes.DataStoreConfig])]
    param()
    begin
    {
        Test-AppVolSession
        $Entity = New-Object -TypeName  VMware.AppVolumes.DataStoreConfig
        $allDataStores = Get-AppVolDataStore
        $AllMachineManagers = Get-AppVolMachineManager
         
        $ApiUri = "$($Global:GlobalSession.Uri)cv_api/datastores"
        $instance = Invoke-InternalGetRest -Uri $ApiUri
        $Entity.AppStackMachineManager = $AllMachineManagers |Where-Object -FilterScript {
            ($_.Id -eq [int]$($instance.appstack_storage).Split('|')[2])
        }
        $Entity.AppStackDefaultPath = $instance.appstack_path
        $Entity.AppStackDefaultStorage = $allDataStores|Where-Object -FilterScript {
            ($_.Name -eq [string]$($instance.appstack_storage).Split('|')[0]) -and ($_.DatacenterName -eq [string]$($instance.appstack_storage).Split('|')[1] )-and ($_.MachineManager.Id -eq [int]$($instance.appstack_storage).Split('|')[2])
        }
        $Entity.AppStackTemplatePath = $instance.appstack_template_path
        $Entity.DatacenterName = $instance.datacenter
        $Entity.WritableMachineManager = $AllMachineManagers |Where-Object -FilterScript {
            ($_.Id -eq [int]$($instance.writable_storage).Split('|')[2])
        }
        $Entity.WritableDefaultPath = $instance.writable_path
        $Entity.WritableDefaultStorage = $allDataStores |Where-Object -FilterScript {
            ($_.Name -eq [string]$($instance.writable_storage).Split('|')[0]) -and ($_.DatacenterName -eq [string]$($instance.writable_storage).Split('|')[1] )-and ($_.MachineManager.Id -eq [int]$($instance.writable_storage).Split('|')[2])
        }
        $Entity.WritableTemplatePath = $instance.writable_template_path

		
    }
	
    end
    {
		
        return $Entity
    }
}

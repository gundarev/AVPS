#requires -Version 2
Function Select-AppVolFiles
{
    [outputtype([System.IO.FileInfo])]
    param(
        [Parameter(Mandatory = $false,Position = 0,ValueFromPipeline = $true)]

        [string]$FolderName,
        
        [Switch]
        $Folder
    )
    $TempDirName = [System.Guid]::NewGuid().ToString()
    $tempDir = New-Item -Type Directory -Name $TempDirName -Path  $env:temp -Force
    [System.IO.FileInfo[]]$filearray = $null
    if ($Folder) 
    {
        $Sourcefolder = Select-FolderDialog -Title 'Select Folder' -Directory $FolderName |
        Get-Item -Force |
        Get-ChildItem -Force
        foreach ($file in $Sourcefolder) 
        {
            $null = Copy-Item  -Path $file.FullName -Destination $tempDir -Recurse -Container -Force
        }
    } 
    else 
    {
        $files = Select-FileDialog -Title 'Select Files' -Directory $FolderName -MultiSelect:$true|Get-Item
        
        foreach ($file in $files) 
        {
            $null = Copy-Item  -Path $file.FullName -Destination $tempDir -Force
        }
    }
    
   
    return $tempDir|Get-ChildItem -Force
}

#requires -Version 3 -Modules AppVol
#.ExternalHelp AppVol.psm1-help.xml
Function Get-AppVolDataStore
{
    [OutputType([Vmware.Appvolumes.DataStore []])]
    [CmdletBinding(DefaultParameterSetName = 'None')]
    param(
     
        [Parameter(ParameterSetName = 'SelectedEntity',Mandatory = $false,Position = 0,ValueFromPipeline = $TRUE,ValueFromPipelineByPropertyName = $TRUE,ValueFromRemainingArguments = $false,HelpMessage = 'Enter one or more AppStack IDs separated by commas.')]
	
        [AllowNull()]
        [int]$Id,
	
	
	
        [ValidateNotNull()]
        [switch]$Accessible,
	
        [ValidateNotNull()] 
        [VMware.AppVolumes.DataStoreCategory]$DataStoreCategory,
	
        [ValidateNotNull()]
        [string]$DataCenterName,
	
        [ValidateNotNull()]
        [int]$DataCenterId,
	
        [ValidateNotNull()]
        [string]$Name,
	
	
        [switch]$Exact,
        [switch]$Like,
	
	
        [switch]$Not
	
    )
    begin
    {
        Test-AppVolSession
        [Vmware.Appvolumes.DataStore []]$Entities = $null
        $allMachineManagers = Get-AppVolMachineManager 
		
        $ApiUri = "$($Global:GlobalSession.Uri)cv_api/datastores"
       
            
        $Datastores = Invoke-InternalGetRest -Uri $ApiUri -Object 'datastores'
     
            
        
    }
    process
    {
        $Datastores = if ($Id) 
        {
            $Datastores|Where-Object -FilterScript {
                $_.id -eq $Id
            } 
        }
        else 
        {
            $Datastores
        } 
                
        foreach ($Entity in $Datastores)
        {
            $LocalEntity = New-Object -TypeName Vmware.Appvolumes.DataStore
		
            if ($Entity.accessible) 
            {
                $LocalEntity.Accessible = $Entity.accessible
            }
            if ($Entity.category) 
            {
                $LocalEntity.DatastoreCategory = $Entity.category
            }
            if ($Entity.uniq_string) 
            {
                $managerId = [int]$($Entity.uniq_string).Split('|')[2]

                $LocalEntity.MachineManager = $allMachineManagers|Where-Object -FilterScript {
                    $_.Id -eq $managerId
                }
            }
            if ($Entity.datacenter) 
            {
                $LocalEntity.DatacenterName = $Entity.datacenter
            }
            if ($Entity.description) 
            {
                $LocalEntity.Description = $Entity.description
            }
            if ($Entity.display_name) 
            {
                $LocalEntity.DisplayName = $Entity.display_name
            }
            if ($Entity.host) 
            {
                $LocalEntity.HostName = $Entity.host
            }
            if ($Entity.id) 
            {
                $LocalEntity.Id = $Entity.id
            }
            if ($Entity.identifier) 
            {
                $LocalEntity.TextIdentifier = $Entity.identifier
            }
            if ($Entity.name) 
            {
                $LocalEntity.Name = $Entity.name
            }
            if ($Entity.note) 
            {
                $LocalEntity.Note = $Entity.note
            }

            $Entities += $LocalEntity
        }
            
        
    }
    end
    {

		
        return Select-FilteredResults $PSCmdlet.MyInvocation.BoundParameters.Keys $Entities
    }
}

#.ExternalHelp AppVol.psm1-help.xml
Function Select-AppVolDataStore
{
    return Get-AppVolDataStore|Out-GridView -OutputMode:Single -Title 'Select DataStore'
}
